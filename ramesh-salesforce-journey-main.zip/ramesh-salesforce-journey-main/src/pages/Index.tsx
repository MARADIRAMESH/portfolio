import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Mail, Phone, MapPin, Linkedin, Github, ExternalLink, Calendar, Award, Briefcase, GraduationCap, Code, Database, Globe, Cpu, Wrench } from "lucide-react";
const Index = () => {
  return <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto">
          <div className="w-32 h-32 bg-white/20 rounded-full mx-auto mb-6 flex items-center justify-center backdrop-blur-sm">
            <span className="text-4xl font-bold text-white">MR</span>
          </div>
          <h1 className="text-5xl font-bold mb-4 animate-fade-in">MARADI RAMESH</h1>
          <p className="text-xl mb-6 opacity-90">Aspiring Salesforce Professional & Software Developer</p>
          <div className="flex flex-wrap justify-center gap-6 text-sm mb-8">
            <div className="flex items-center gap-2">
              <MapPin size={16} />
              <span>Hyderabad, Telangana</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail size={16} />
              <span>maradiramesh@2002@gmail.com</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={16} />
              <span>+91 7659858284</span>
            </div>
          </div>
          <div className="flex justify-center gap-4">
            <Button variant="secondary" size="lg" className="bg-white/20 backdrop-blur-sm hover:bg-white/30">
              <Linkedin className="mr-2" size={20} />
              LinkedIn
            </Button>
            <Button variant="secondary" size="lg" className="bg-white/20 backdrop-blur-sm hover:bg-white/30">
              <Github className="mr-2" size={20} />
              GitHub
            </Button>
          </div>
        </div>
      </section>

      {/* Objective Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <Card className="shadow-lg border-0 bg-white/70 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl text-center">🎯 Objective</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg text-gray-700 leading-relaxed text-center max-w-4xl mx-auto">
                Aspiring Salesforce professional with strong foundation in Java, SQL, and web technologies. 
                Eager to apply my problem-solving skills and technical knowledge to Salesforce development and administration. 
                Currently expanding expertise through Trailhead learning paths.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Technical Skills Section */}
      <section className="py-16 px-4 bg-white/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">💻 Technical Skills</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="text-blue-600" />
                  Programming
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Java</Badge>
                  <Badge variant="secondary">JavaScript</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="text-green-600" />
                  Database
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">SQL</Badge>
                  <Badge variant="outline">SOQL (Learning)</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="text-purple-600" />
                  Salesforce
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Objects & Relationships</Badge>
                  <Badge variant="secondary">Reports & Dashboards</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="text-orange-600" />
                  Web Technologies
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">HTML5</Badge>
                  <Badge variant="secondary">CSS3</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="text-red-600" />
                  Hardware/IoT
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Arduino</Badge>
                  <Badge variant="secondary">GSM/GPS Modules</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Wrench className="text-gray-600" />
                  Tools
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Git</Badge>
                  <Badge variant="secondary">VS Code</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 flex items-center justify-center gap-2">
            <GraduationCap className="text-blue-600" />
            🎓 Education
          </h2>
          <div className="space-y-6">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Pallavi Engineering College</CardTitle>
                <CardDescription>B.Tech in Electronics and Communication Engineering</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">CGPA: 7.0/10</span>
                  <span className="text-gray-600">2020–2024</span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Government Polytechnic College</CardTitle>
                <CardDescription>Diploma in ECE</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">CGPA: 8.43/10</span>
                  <span className="text-gray-600">2018–2021</span>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Zilla Parishad High School</CardTitle>
                <CardDescription>SSC</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">CGPA: 8.8/10</span>
                  <span className="text-gray-600">2017–2018</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16 px-4 bg-white/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">👨‍💻 Projects</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle>Hostel Management System</CardTitle>
                <CardDescription>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <Badge variant="outline">HTML</Badge>
                    <Badge variant="outline">CSS</Badge>
                    <Badge variant="outline">Java</Badge>
                    <Badge variant="outline">MySQL</Badge>
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-4">Jan 2023</p>
                <ul className="space-y-2 text-sm">
                  <li>• Developed full-stack web application for room allocation and billing</li>
                  <li>• Integrated payment gateway reducing manual processing by 30%</li>
                  <li>• Implemented admin/student role-based access control</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader>
                <CardTitle>Accident Prevention & Alert System</CardTitle>
                <CardDescription>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <Badge variant="outline">Arduino</Badge>
                    <Badge variant="outline">GPS</Badge>
                    <Badge variant="outline">GSM</Badge>
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-4">Aug 2022</p>
                <ul className="space-y-2 text-sm">
                  <li>• Designed prototype detecting collisions using impact sensors</li>
                  <li>• Automated emergency alerts via SMS with &lt;10s response time</li>
                  <li>• Won college innovation challenge</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 flex items-center justify-center gap-2">
            <Briefcase className="text-blue-600" />
            💼 Experience
          </h2>
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Act Fiber - Junior Network Engineer Intern</CardTitle>
              <CardDescription>Dec 2020–May 2021</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li>• Assisted in network troubleshooting and maintenance tasks</li>
                <li>• Documented system configurations improving team workflow</li>
                <li>• Participated in fiber network deployment project</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Certifications & Achievements */}
      <section className="py-16 px-4 bg-white/50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-3xl font-bold text-center mb-8 flex items-center justify-center gap-2">
                <Award className="text-yellow-600" />
                📜 Certifications
              </h2>
              <div className="space-y-4">
                <Card className="shadow-lg">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold">Oracle Certified Java Programmer</h3>
                    <p className="text-gray-600">2023</p>
                  </CardContent>
                </Card>
                <Card className="shadow-lg">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold">Salesforce Trailhead: Admin Beginner Path</h3>
                    <p className="text-gray-600">2025</p>
                  </CardContent>
                </Card>
                <Card className="shadow-lg">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold">Udemy HTML/CSS Certification</h3>
                    <p className="text-gray-600">2022</p>
                  </CardContent>
                </Card>
                <Card className="shadow-lg">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold">NCC 'A' Certificate</h3>
                    <p className="text-gray-600">2021</p>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-center mb-8">🏆 Achievements</h2>
              <div className="space-y-4">
                <Card className="shadow-lg">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold">Ramanujan Award</h3>
                    <p className="text-gray-600">Telangana Mathematics Forum (Top 10% statewide) | 2019</p>
                  </CardContent>
                </Card>
                <Card className="shadow-lg">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold">State Level Talent Test Winner</h3>
                    <p className="text-gray-600">Social Sciences | 2018</p>
                  </CardContent>
                </Card>
                <Card className="shadow-lg">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold">Innovation Champion</h3>
                    <p className="text-gray-600">Developed 2 functional hardware/software prototypes during engineering</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Salesforce Learning Path */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Salesforce Learning Path</h2>
          <Card className="shadow-lg bg-gray-900 text-white">
            <CardHeader>
              <CardTitle className="text-center">Progress Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 font-mono">
                <div className="flex items-center gap-2">
                  <span className="text-green-400">+ Completed:</span>
                  <span>Data Modeling, Security Basics</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-yellow-400">! In Progress:</span>
                  <span>Flow Automation, Reports</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-red-400">- Planned:</span>
                  <span>Apex Fundamentals</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-gray-900 text-white text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-6">Let's Connect!</h2>
          <p className="text-gray-300 mb-6">
            Ready to contribute to innovative Salesforce solutions and continue learning new technologies.
          </p>
          <div className="flex justify-center gap-4">
            <Button variant="outline" className="bg-white/10 border-white/20 hover:bg-white/20">
              <Mail className="mr-2" size={20} />
              Email Me
            </Button>
            <Button variant="outline" className="bg-white/10 border-white/20 hover:bg-white/20">
              <Linkedin className="mr-2" size={20} />
              LinkedIn
            </Button>
          </div>
        </div>
      </footer>
    </div>;
};
export default Index;